/**
* Lab06 Questions
* Adam Schilperoot, Keil Hubbard
* CS136L, Sect. 002
* 03.09.2018
*
* Extend Question class to handle Numeric questions & answers.
* (Most similar to Question superclass vs FillIn & AnyCorrect)
* If answer differs by no more than 0.01, accept as correct.
*/
public class NumericQuestion extends Question{

  private double answer;
  private final int pointValue = 1;
  /**
     Constructs a question with empty question and answer.
  */
  public NumericQuestion()
  {
     answer = 0.0;
  }

  /**
     Sets the answer for this question.
     @param correctResponse the answer
  */
  public void setAnswer(double correctResponse)
  {
     answer = correctResponse;
  }

  /**
  * Return point value of Numeric Question.
  */
  public int getValue(){
    return pointValue;
  }

  /**
     Checks a given response for correctness.
     @param response the response to check
     @return true if the response was correct, false otherwise
  */
  public boolean checkAnswer(String response)
  {
    // Convert String response to Double, allows presentQuestion
    // in QuestionsApp to remain unchanged.
    Double parseResponse = Double.parseDouble(response);
     if (answer==parseResponse){
       return true;
     }
     if (answer < parseResponse){
       if ((parseResponse-answer) <= 0.01){
         return true;
       }
     }
     if (parseResponse < answer){
       if((answer-parseResponse) <= 0.01){
         return true;
       }
     }
     return false;
  }
}
