package lightsoutgame;

class LightsOut {

    private int size;
    private boolean[][] grid;
    
    
    public LightsOut(int size) {
            this.size = size;
            grid = new boolean[size][size];
                for( int i=0; i<size; i++){
                    for(int j=0; j<size; j++){
                        grid[i][j]= false;
                    }
                }
    }

    public int getSize(){
        return size;
    }

    public void press(int row, int col) {
        toggle(row,col);
        toggle(row-1, col);
        toggle(row, col-1);
        toggle(row,col+1);
        toggle(row+1, col);
    }

    public boolean isLit(int row, int col) {
        return grid[row][col];
    }

    public void forceLit(int row, int col, boolean value) {
        grid[row][col]=value;
    }

    private void toggle(int row, int col) {
        try{
                grid[row][col]=!grid[row][col];
            
        }
        catch(ArrayIndexOutOfBoundsException ex){
        }   
    }
    
}