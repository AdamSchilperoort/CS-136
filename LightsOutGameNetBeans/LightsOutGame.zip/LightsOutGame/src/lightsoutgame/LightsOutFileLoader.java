package lightsoutgame;

import java.io.*;
import java.util.Scanner;
import java.util.NoSuchElementException;
import javax.swing.JOptionPane;

class LightsOutFileLoader {

    public LightsOutFileLoader() {
    }

    public void load(LightsOut lightsOut, File file) throws IOException, UnsupportedLightsOutFileException{
        try{
        Scanner inputFile = new Scanner(file);
        
        for(int row = 0; row < lightsOut.getSize(); row++){
            String Line;
            char a;
               try{
                    Line = inputFile.nextLine();
                        for(int i=0; i<Line.length(); i++){
                           a=Line.charAt(i);
                           if(a=='X'){
                               lightsOut.forceLit(row, i, false);
                           }
                           else if(a=='_'){
                               lightsOut.forceLit(row, i, true);
                           }
                           else{
                            throw new UnsupportedLightsOutFileException();
                           }
                           
                        }
                }
                catch(NoSuchElementException ex){
                    throw new UnsupportedLightsOutFileException();
                }
        }
        
        inputFile.close();
        }
        catch(FileNotFoundException ex){
            System.out.print("File Not Found");
        }
      /*  catch (IOException ex) {
            System.out.print("Error");
        } */
    }
}
